import { useState } from "react";
import { trpc } from "@/lib/trpc";
import "../styles/grimorio-original.css";

interface SheetData {
  sheet: {
    id: number;
    userId: number;
    characterName: string;
    createdAt: Date;
    updatedAt: Date;
  };
  skills: Array<{
    id: number;
    characterSheetId: number;
    skillName: string;
    level: number;
    createdAt: Date;
    updatedAt: Date;
  }>;
  wounds: Array<{
    id: number;
    characterSheetId: number;
    quantity: number;
    description: string;
    createdAt: Date;
    updatedAt: Date;
  }>;
  bagItems: Array<{
    id: number;
    characterSheetId: number;
    itemName: string;
    createdAt: Date;
    updatedAt: Date;
  }>;
  fortune: {
    id: number;
    characterSheetId: number;
    currentPoints: number;
    maxPoints: number;
    createdAt: Date;
    updatedAt: Date;
  } | null;
}

const LEVEL_NAMES = ["", "I", "II", "III", "IV", "V"];

export default function MasterPanel() {
  const [selectedSheet, setSelectedSheet] = useState<SheetData | null>(null);
  const { data: allSheets, isLoading, error } = trpc.master.listAllSheets.useQuery();

  // Calcular modificador de strikes
  const getStrikeModifier = (strikes: number): number => {
    if (strikes <= 0) return 0;
    if (strikes <= 2) return 0;
    if (strikes <= 4) return -1;
    if (strikes <= 6) return -2;
    if (strikes <= 9) return -3;
    if (strikes <= 12) return -4;
    if (strikes <= 15) return -5;
    return -6;
  };

  if (error) {
    return (
      <div className="grim-wrap">
        <div className="grim-inner">
          <div style={{ padding: "2rem", textAlign: "center", color: "var(--blood2)" }}>
            <h2>Acesso Negado</h2>
            <p>Apenas mestres podem acessar este painel.</p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="grim-wrap">
        <div className="grim-inner">
          <div style={{ padding: "2rem", textAlign: "center", color: "var(--gold2)" }}>
            <p>Carregando fichas...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grim-wrap">
      <div className="grim-inner">
        <div className="nav-wrap">
          <div style={{ textAlign: "center", padding: "1rem" }}>
            <h1 className="ch-title">Painel do Mestre</h1>
            <p style={{ color: "var(--gold)", fontSize: "12px", letterSpacing: "2px" }}>
              Fichas Ativas: {allSheets?.length || 0}
            </p>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: "1rem", padding: "1rem 1.5rem" }}>
          {/* Lista de Fichas */}
          <div>
            <div className="scroll">
              <div className="scroll-title">Jogadores Ativos</div>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {!allSheets || allSheets.length === 0 ? (
                  <p style={{ color: "rgba(244,234,208,0.5)", fontSize: "14px", textAlign: "center", padding: "1rem" }}>
                    Nenhuma ficha ativa
                  </p>
                ) : (
                  allSheets.map((sheetData) => (
                    <button
                      key={sheetData.sheet.id}
                      onClick={() => setSelectedSheet(sheetData)}
                      style={{
                        padding: "12px",
                        background: selectedSheet?.sheet.id === sheetData.sheet.id
                          ? "rgba(201,149,42,0.2)"
                          : "rgba(10,6,2,0.4)",
                        border: selectedSheet?.sheet.id === sheetData.sheet.id
                          ? "1px solid var(--gold2)"
                          : "1px solid rgba(201,149,42,0.2)",
                        borderRadius: "2px",
                        color: "var(--parchment2)",
                        cursor: "pointer",
                        transition: "all 0.2s",
                        textAlign: "left",
                        fontFamily: "'Cinzel', serif",
                        fontSize: "14px",
                      }}
                    >
                      {sheetData.sheet.characterName}
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Detalhes da Ficha */}
          <div>
            {selectedSheet ? (
              <>
                {/* Nome */}
                <div className="scroll">
                  <div className="scroll-title">Identidade</div>
                  <p style={{ fontSize: "18px", color: "var(--gold2)", textAlign: "center", padding: "1rem" }}>
                    {selectedSheet.sheet.characterName}
                  </p>
                </div>

                {/* Strikes */}
                <div className="scroll">
                  <div className="scroll-title">Strikes</div>
                  <div className="strikes-header">
                    <div>
                      <div className="strikes-counter-big">
                        {selectedSheet.wounds.reduce((sum, w) => sum + w.quantity, 0)}
                      </div>
                      <div className="strikes-label">strikes acumulados</div>
                    </div>
                    <div className="strikes-modifier-box">
                      <div className={`strikes-mod-val ${getStrikeModifier(selectedSheet.wounds.reduce((sum, w) => sum + w.quantity, 0)) === 0 ? "safe" : ""}`}>
                        {getStrikeModifier(selectedSheet.wounds.reduce((sum, w) => sum + w.quantity, 0))}
                      </div>
                      <div className={`strikes-mod-label ${getStrikeModifier(selectedSheet.wounds.reduce((sum, w) => sum + w.quantity, 0)) === 0 ? "safe" : ""}`}>
                        {getStrikeModifier(selectedSheet.wounds.reduce((sum, w) => sum + w.quantity, 0)) === 0 ? "sem penalidade" : "penalidade"}
                      </div>
                    </div>
                  </div>

                  {/* Ferimentos */}
                  <div className="strike-wound-list">
                    {selectedSheet.wounds.length === 0 ? (
                      <p style={{ color: "rgba(244,234,208,0.5)", textAlign: "center", padding: "1rem" }}>
                        Sem ferimentos
                      </p>
                    ) : (
                      selectedSheet.wounds.map((wound) => (
                        <div key={wound.id} className="strike-wound-item">
                          <span className="wound-count-badge">{wound.quantity}</span>
                          <span className="wound-desc">{wound.description}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Perícias */}
                <div className="scroll">
                  <div className="scroll-title">Perícias</div>
                  <div className="skill-list">
                    {selectedSheet.skills.length === 0 ? (
                      <p style={{ color: "rgba(244,234,208,0.5)", textAlign: "center", padding: "1rem" }}>
                        Nenhuma perícia
                      </p>
                    ) : (
                      selectedSheet.skills.map((skill) => (
                        <div key={skill.id} className={`skill-card skill-lv${skill.level}`}>
                          <div className="skill-card-header">
                            <span className="skill-card-name">{skill.skillName}</span>
                            <span className="skill-card-level">Nível {LEVEL_NAMES[skill.level]}</span>
                          </div>
                          <p style={{ fontSize: "12px", color: "rgba(244,234,208,0.6)", marginTop: "8px" }}>
                            {skill.level}d6
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Mochila */}
                <div className="scroll">
                  <div className="scroll-title">Mochila</div>
                  <div className="bag-grid">
                    {selectedSheet.bagItems.length === 0 ? (
                      <div className="bag-empty">Nenhum item</div>
                    ) : (
                      selectedSheet.bagItems.map((item, idx) => (
                        <div key={item.id} className="bag-item">
                          <span className="bag-item-num">{idx + 1}</span>
                          <span className="bag-item-name">{item.itemName}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Sorte */}
                {selectedSheet.fortune && (
                  <div className="scroll">
                    <div className="scroll-title">Sorte</div>
                    <div className="luck-section">
                      <div className="luck-header">
                        <span className="luck-name">Pontos de Sorte</span>
                        <span className="luck-val">
                          {selectedSheet.fortune.currentPoints}/{selectedSheet.fortune.maxPoints}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="scroll">
                <p style={{ color: "rgba(244,234,208,0.5)", textAlign: "center", padding: "2rem" }}>
                  Selecione um jogador para ver os detalhes
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
