import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import "../styles/grimorio-original.css";

interface Skill {
  id: number;
  name: string;
  level: number;
}

interface Wound {
  id: number;
  description: string;
  quantity: number;
}

interface BagItem {
  id: number;
  name: string;
}

const LEVEL_NAMES = ["", "I", "II", "III", "IV", "V"];

export default function GrimorioCharacter() {
  const [playerName, setPlayerName] = useState("");
  const [characterName, setCharacterName] = useState("");
  const [activeTab, setActiveTab] = useState("intro");
  const [skills, setSkills] = useState<Skill[]>([
    { id: 1, name: "Fazer Algo", level: 1 }
  ]);
  const [wounds, setWounds] = useState<Wound[]>([]);
  const [bagItems, setBagItems] = useState<BagItem[]>([]);
  const [luck, setLuck] = useState(100);
  const [diceRolls, setDiceRolls] = useState<{ [key: number]: number[] }>({});
  const [showNewSkillModal, setShowNewSkillModal] = useState(false);
  const [newSkillName, setNewSkillName] = useState("");
  const [woundQty, setWoundQty] = useState(1);
  const [woundDesc, setWoundDesc] = useState("");
  const [bagInput, setBagInput] = useState("");

  // Calcular modificador de strikes
  const totalStrikes = wounds.reduce((sum, w) => sum + w.quantity, 0);
  const getStrikeModifier = (strikes: number): number => {
    if (strikes <= 0) return 0;
    if (strikes <= 2) return 0;
    if (strikes <= 4) return -1;
    if (strikes <= 6) return -2;
    if (strikes <= 9) return -3;
    if (strikes <= 12) return -4;
    if (strikes <= 15) return -5;
    return -6;
  };

  const strikeModifier = getStrikeModifier(totalStrikes);

  // Rolar dados
  const rollSkill = (skillId: number, level: number) => {
    const rolls: number[] = [];
    for (let i = 0; i < level; i++) {
      rolls.push(Math.floor(Math.random() * 6) + 1);
    }
    setDiceRolls({ ...diceRolls, [skillId]: rolls });

    const best = Math.max(...rolls);
    const countSixes = rolls.filter(r => r === 6).length;

    // Fazer Algo nível 1 com 6 = nova perícia
    if (skillId === 1 && level === 1 && best === 6) {
      setShowNewSkillModal(true);
      return;
    }

    // Duplo 6 = evolução
    if (skillId !== 1 && countSixes >= 2) {
      const skill = skills.find(s => s.id === skillId);
      if (skill && skill.level < 5) {
        const updated = skills.map(s =>
          s.id === skillId ? { ...s, level: s.level + 1 } : s
        );
        setSkills(updated);
      }
      return;
    }

    // 6 único em nível 1 = evolução para nível 2
    if (skillId !== 1 && level === 1 && best === 6) {
      const updated = skills.map(s =>
        s.id === skillId ? { ...s, level: 2 } : s
      );
      setSkills(updated);
    }
  };

  // Adicionar nova perícia
  const confirmNewSkill = () => {
    if (newSkillName.trim()) {
      const newId = Math.max(...skills.map(s => s.id), 0) + 1;
      setSkills([...skills, { id: newId, name: newSkillName, level: 2 }]);
      setNewSkillName("");
      setShowNewSkillModal(false);
    }
  };

  // Adicionar ferimento
  const addWound = () => {
    if (woundDesc.trim()) {
      const newId = Math.max(...wounds.map(w => w.id), 0) + 1;
      setWounds([...wounds, { id: newId, description: woundDesc, quantity: woundQty }]);
      setWoundDesc("");
      setWoundQty(1);
    }
  };

  // Remover ferimento
  const removeWound = (id: number) => {
    setWounds(wounds.filter(w => w.id !== id));
  };

  // Adicionar item à mochila
  const addBagItem = () => {
    if (bagInput.trim()) {
      const newId = Math.max(...bagItems.map(b => b.id), 0) + 1;
      setBagItems([...bagItems, { id: newId, name: bagInput }]);
      setBagInput("");
    }
  };

  // Remover item da mochila
  const removeBagItem = (id: number) => {
    setBagItems(bagItems.filter(b => b.id !== id));
  };

  return (
    <div className="grim-wrap">
      <div className="grim-inner">
        {/* NAVEGAÇÃO */}
        <div className="nav-wrap">
          <div className="nav">
            <button
              className={`nav-btn ${activeTab === "intro" ? "active" : ""}`}
              onClick={() => setActiveTab("intro")}
            >
              Introdução
            </button>
            <button
              className={`nav-btn ${activeTab === "pericias" ? "active" : ""}`}
              onClick={() => setActiveTab("pericias")}
            >
              Perícias
            </button>
            <button
              className={`nav-btn ${activeTab === "strikes" ? "active" : ""}`}
              onClick={() => setActiveTab("strikes")}
            >
              Strikes & Dano
            </button>
            <button
              className={`nav-btn ${activeTab === "sorte" ? "active" : ""}`}
              onClick={() => setActiveTab("sorte")}
            >
              Sorte
            </button>
            <button
              className={`nav-btn ${activeTab === "personagem" ? "active" : ""}`}
              onClick={() => setActiveTab("personagem")}
            >
              Personagem
            </button>
          </div>
        </div>

        {/* INTRO */}
        {activeTab === "intro" && (
          <div className="chapter active">
            <div className="ch-head">
              <h2 className="ch-title">Fundamentos do Sistema</h2>
            </div>
            <div className="scroll">
              <div className="scroll-title">O Dado Universal</div>
              <p>Todos os testes utilizam <span style={{ color: "var(--gold2)" }}>1d6</span>. Conforme a campanha avança e as perícias evoluem, mais dados são rolados — valendo sempre o resultado mais alto.</p>
            </div>
          </div>
        )}

        {/* PERICIAS */}
        {activeTab === "pericias" && (
          <div className="chapter active">
            <div className="ch-head">
              <h2 className="ch-title">Perícias</h2>
            </div>
            <div className="scroll">
              <div className="scroll-title">Origem & Evolução</div>
              <p>Todo aventureiro começa com uma única perícia: <span style={{ color: "var(--gold2)" }}>Fazer Algo (I)</span>. Ao obter um sucesso crítico — um 6 no dado — a ação realizada torna-se uma nova perícia registrada na ficha no nível I.</p>
            </div>
          </div>
        )}

        {/* STRIKES */}
        {activeTab === "strikes" && (
          <div className="chapter active">
            <div className="ch-head">
              <h2 className="ch-title">Strikes & Dano</h2>
            </div>
            <div className="scroll">
              <div className="scroll-title">O Acúmulo de Feridas</div>
              <p>A cada <span style={{ color: "var(--gold2)" }}>3 strikes</span>, o personagem recebe um modificador permanente de <span style={{ color: "#e08080" }}>−1</span> em todos os testes.</p>
            </div>
          </div>
        )}

        {/* SORTE */}
        {activeTab === "sorte" && (
          <div className="chapter active">
            <div className="ch-head">
              <h2 className="ch-title">Sorte do Protagonista</h2>
            </div>
            <div className="scroll">
              <div className="scroll-title">A Barra de Sorte</div>
              <p>Aplica-se somente a golpes balísticos. Começa em 100%. Abaixo de 18%: perigo real.</p>
              <div className="luck-section">
                <div className="luck-header">
                  <span className="luck-name">Sorte Atual</span>
                  <span className="luck-val">{luck}%</span>
                </div>
                <div className="luck-track">
                  <div
                    className={`luck-fill ${luck >= 50 ? "luck-safe" : luck >= 18 ? "luck-warn" : "luck-danger"}`}
                    style={{ width: `${luck}%` }}
                  >
                    <span className="luck-fill-txt">
                      {luck >= 50 ? "Seguro" : luck >= 18 ? "Perigo" : "Crítico"}
                    </span>
                  </div>
                  <div className="luck-marker"></div>
                </div>
              </div>
              <div style={{ marginTop: "1rem" }}>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={luck}
                  onChange={(e) => setLuck(parseInt(e.target.value))}
                  style={{ width: "100%", marginBottom: "0.5rem" }}
                />
              </div>
            </div>
          </div>
        )}

        {/* PERSONAGEM */}
        {activeTab === "personagem" && (
          <div className="chapter active">
            <div className="ch-head">
              <h2 className="ch-title">Ficha do Personagem</h2>
            </div>

            {/* Nome */}
            <div className="scroll">
              <div className="scroll-title">Identidade</div>
              <input
                className="char-name-input"
                type="text"
                placeholder="Nome do Personagem"
                value={characterName}
                onChange={(e) => setCharacterName(e.target.value)}
                maxLength={40}
              />
            </div>

            {/* STRIKES */}
            <div className="scroll">
              <div className="scroll-title">Strikes</div>
              <div className="strikes-header">
                <div>
                  <div className="strikes-counter-big">{totalStrikes}</div>
                  <div className="strikes-label">strikes acumulados</div>
                </div>
                <div className="strikes-modifier-box">
                  <div className={`strikes-mod-val ${strikeModifier === 0 ? "safe" : ""}`}>
                    {strikeModifier}
                  </div>
                  <div className={`strikes-mod-label ${strikeModifier === 0 ? "safe" : ""}`}>
                    {strikeModifier === 0 ? "sem penalidade" : "penalidade"}
                  </div>
                </div>
              </div>

              {/* Pips visuais */}
              <div className="strike-pip-row">
                {Array.from({ length: Math.min(totalStrikes, 18) }).map((_, i) => (
                  <div
                    key={i}
                    className={`strike-pip ${i < totalStrikes ? "filled" : ""} ${
                      (i + 1) % 3 === 0 && i < totalStrikes ? "three-mark" : ""
                    }`}
                  >
                    {(i + 1) % 3 === 0 && i < totalStrikes ? "✦" : ""}
                  </div>
                ))}
              </div>

              {/* Ferimentos */}
              <div className="strike-wound-list">
                {wounds.map((wound) => (
                  <div key={wound.id} className="strike-wound-item">
                    <span className="wound-count-badge">{wound.quantity}</span>
                    <span className="wound-desc">{wound.description}</span>
                    <button
                      className="wound-remove"
                      onClick={() => removeWound(wound.id)}
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>

              {/* Adicionar ferimento */}
              <div className="add-strike-row">
                <input
                  className="strike-qty-input"
                  type="number"
                  min="1"
                  max="18"
                  value={woundQty}
                  onChange={(e) => setWoundQty(parseInt(e.target.value))}
                  placeholder="qtd"
                />
                <input
                  className="strike-desc-input"
                  type="text"
                  placeholder="Descreva o ferimento..."
                  value={woundDesc}
                  onChange={(e) => setWoundDesc(e.target.value)}
                  maxLength={60}
                />
                <button className="add-btn" onClick={addWound}>
                  + Adicionar
                </button>
              </div>
            </div>

            {/* PERICIAS */}
            <div className="scroll">
              <div className="scroll-title">Perícias</div>
              <p style={{ fontSize: "14px", color: "rgba(244,234,208,0.5)", fontStyle: "italic", marginBottom: "1rem" }}>
                Role cada perícia. Um <span style={{ color: "var(--gold2)" }}>6</span> em Fazer Algo revela uma nova habilidade. Dois <span style={{ color: "var(--gold2)" }}>6s</span> simultâneos avançam de nível.
              </p>
              <div className="skill-list">
                {skills.map((skill) => (
                  <div key={skill.id} className={`skill-card skill-lv${skill.level}`}>
                    <div className="skill-card-header">
                      <span className="skill-card-name">{skill.name}</span>
                      <span className="skill-card-level">Nível {LEVEL_NAMES[skill.level]}</span>
                    </div>
                    <div className="skill-dice-row">
                      {Array.from({ length: skill.level }).map((_, i) => (
                        <div key={i} className="die-face">
                          {diceRolls[skill.id]?.[i] || "?"}
                        </div>
                      ))}
                    </div>
                    <button
                      className="roll-btn"
                      onClick={() => rollSkill(skill.id, skill.level)}
                    >
                      Rolar {skill.level}d6
                    </button>
                    {diceRolls[skill.id] && (
                      <div className="skill-result result-good">
                        Resultado: {Math.max(...diceRolls[skill.id])}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* MOCHILA */}
            <div className="scroll">
              <div className="scroll-title">Mochila</div>
              <p style={{ fontSize: "14px", color: "rgba(244,234,208,0.5)", fontStyle: "italic", marginBottom: "0.75rem" }}>
                O que você carrega nesta jornada.
              </p>
              <div className="bag-grid">
                {bagItems.length === 0 ? (
                  <div className="bag-empty">Nenhum item na mochila</div>
                ) : (
                  bagItems.map((item, idx) => (
                    <div key={item.id} className="bag-item">
                      <span className="bag-item-num">{idx + 1}</span>
                      <span className="bag-item-name">{item.name}</span>
                      <button
                        className="bag-remove"
                        onClick={() => removeBagItem(item.id)}
                      >
                        ✕
                      </button>
                    </div>
                  ))
                )}
              </div>
              <div className="add-bag-row">
                <input
                  className="bag-input"
                  type="text"
                  placeholder="Adicionar item à mochila..."
                  value={bagInput}
                  onChange={(e) => setBagInput(e.target.value)}
                  maxLength={50}
                />
                <button className="add-btn" onClick={addBagItem}>
                  + Guardar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* MODAL - Nova Perícia */}
      {showNewSkillModal && (
        <div className="modal-overlay">
          <div className="modal-box">
            <div className="modal-critical-star">✦</div>
            <p className="modal-title">Crítico!</p>
            <p className="modal-sub">Nova perícia desbloqueada</p>
            <p style={{ fontSize: "15px", color: "rgba(244,234,208,0.7)", textAlign: "center", marginBottom: "1.25rem", lineHeight: "1.7" }}>
              A ação foi executada com maestria.<br />
              Que nome carrega esta habilidade?
            </p>
            <input
              className="modal-input"
              type="text"
              placeholder="Nome da perícia"
              value={newSkillName}
              onChange={(e) => setNewSkillName(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && confirmNewSkill()}
            />
            <div className="modal-btns">
              <button className="modal-btn-confirm" onClick={confirmNewSkill}>
                Confirmar
              </button>
              <button
                className="modal-btn-cancel"
                onClick={() => {
                  setShowNewSkillModal(false);
                  setNewSkillName("");
                }}
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
