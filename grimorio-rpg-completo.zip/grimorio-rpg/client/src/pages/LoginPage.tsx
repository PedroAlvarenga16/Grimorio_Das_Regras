import { useState } from "react";
import { useLocation } from "wouter";
import "../styles/grimorio-original.css";

export default function LoginPage() {
  const [playerName, setPlayerName] = useState("");
  const [, setLocation] = useLocation();

  const handleLogin = () => {
    if (playerName.trim()) {
      // Salvar o nome do jogador no localStorage
      localStorage.setItem("playerName", playerName);
      localStorage.setItem("playerNameSet", "true");
      // Redirecionar para a ficha
      setLocation("/character");
    }
  };

  return (
    <div className="grim-wrap">
      <div className="grim-inner">
        <div style={{ paddingTop: "4rem", textAlign: "center" }}>
          <h1 className="ch-title" style={{ marginBottom: "2rem" }}>
            Grimório LDL II
          </h1>
          <p style={{ color: "var(--parchment2)", marginBottom: "3rem", fontSize: "18px" }}>
            Bem-vindo, aventureiro. Qual é o seu nome?
          </p>

          <div className="scroll" style={{ maxWidth: "400px", margin: "0 auto" }}>
            <input
              className="char-name-input"
              type="text"
              placeholder="Seu nome..."
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleLogin()}
              maxLength={40}
              autoFocus
            />
            <button
              className="roll-btn"
              onClick={handleLogin}
              style={{ marginTop: "1.5rem", width: "100%", padding: "12px" }}
            >
              Entrar na Aventura
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
