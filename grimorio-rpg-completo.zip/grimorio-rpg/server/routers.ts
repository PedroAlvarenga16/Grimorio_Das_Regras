import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { eq, and } from "drizzle-orm";
import { characterSheets, skills, wounds, bagItems, fortune } from "../drizzle/schema";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Character Sheet procedures
  character: router({
    // Criar ou obter ficha do jogador
    getOrCreate: protectedProcedure
      .input(z.object({ playerName: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const existing = await db
          .select()
          .from(characterSheets)
          .where(and(
            eq(characterSheets.userId, ctx.user!.id),
            eq(characterSheets.characterName, input.playerName)
          ))
          .limit(1);

        if (existing.length > 0) {
          return existing[0];
        }

        // Criar nova ficha
        await db.insert(characterSheets).values({
          userId: ctx.user!.id,
          characterName: input.playerName,
        });

        // Obter a ficha criada (pega a mais recente do usuário)
        const created = await db
          .select()
          .from(characterSheets)
          .where(eq(characterSheets.userId, ctx.user!.id))
          .limit(1);

        // Criar perícia inicial "Fazer Algo"
        if (created.length > 0) {
          await db.insert(skills).values({
            characterSheetId: created[0].id,
            skillName: "Fazer Algo",
            level: 1,
          });

          // Criar fortune inicial
          await db.insert(fortune).values({
            characterSheetId: created[0].id,
            currentPoints: 3,
            maxPoints: 3,
          });
        }

        return created[0];
      }),

    // Obter ficha completa
    getSheet: protectedProcedure
      .input(z.object({ characterSheetId: z.number() }))
      .query(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const sheet = await db
          .select()
          .from(characterSheets)
          .where(eq(characterSheets.id, input.characterSheetId))
          .limit(1);

        if (!sheet.length) return null;

        const sheetData = sheet[0];

        // Obter perícias
        const sheetSkills = await db
          .select()
          .from(skills)
          .where(eq(skills.characterSheetId, input.characterSheetId));

        // Obter ferimentos
        const sheetWounds = await db
          .select()
          .from(wounds)
          .where(eq(wounds.characterSheetId, input.characterSheetId));

        // Obter itens
        const sheetItems = await db
          .select()
          .from(bagItems)
          .where(eq(bagItems.characterSheetId, input.characterSheetId));

        // Obter sorte
        const sheetFortune = await db
          .select()
          .from(fortune)
          .where(eq(fortune.characterSheetId, input.characterSheetId))
          .limit(1);

        return {
          sheet: sheetData,
          skills: sheetSkills,
          wounds: sheetWounds,
          bagItems: sheetItems,
          fortune: sheetFortune[0] || null,
        };
      }),

    // Atualizar nome do personagem
    updateCharacterName: protectedProcedure
      .input(z.object({ characterSheetId: z.number(), characterName: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(characterSheets)
          .set({ characterName: input.characterName })
          .where(eq(characterSheets.id, input.characterSheetId));

        return { success: true };
      }),
  }),

  // Skills procedures
  skills: router({
    add: protectedProcedure
      .input(z.object({ characterSheetId: z.number(), skillName: z.string(), level: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(skills).values({
          characterSheetId: input.characterSheetId,
          skillName: input.skillName,
          level: input.level,
        });

        return { success: true }
      }),

    update: protectedProcedure
      .input(z.object({ skillId: z.number(), level: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(skills)
          .set({ level: input.level })
          .where(eq(skills.id, input.skillId));

        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ skillId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.delete(skills).where(eq(skills.id, input.skillId));
        return { success: true };
      }),
  }),

  // Wounds procedures
  wounds: router({
    add: protectedProcedure
      .input(z.object({ characterSheetId: z.number(), description: z.string(), quantity: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(wounds).values({
          characterSheetId: input.characterSheetId,
          description: input.description,
          quantity: input.quantity,
        });

        return { success: true }
      }),

    delete: protectedProcedure
      .input(z.object({ woundId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.delete(wounds).where(eq(wounds.id, input.woundId));
        return { success: true };
      }),
  }),

  // Bag items procedures
  bagItems: router({
    add: protectedProcedure
      .input(z.object({ characterSheetId: z.number(), itemName: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(bagItems).values({
          characterSheetId: input.characterSheetId,
          itemName: input.itemName,
        });

        return { success: true }
      }),

    delete: protectedProcedure
      .input(z.object({ bagItemId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.delete(bagItems).where(eq(bagItems.id, input.bagItemId));
        return { success: true };
      }),
  }),

  // Fortune procedures
  fortune: router({
    update: protectedProcedure
      .input(z.object({ characterSheetId: z.number(), currentPoints: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(fortune)
          .set({ currentPoints: input.currentPoints })
          .where(eq(fortune.characterSheetId, input.characterSheetId));

        return { success: true };
      }),
  }),

  // Master panel procedures
  master: router({
    // Listar todas as fichas dos jogadores (apenas para admin)
    listAllSheets: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Se não for admin, retorna vazio
      if (ctx.user?.role !== "admin") {
        return [];
      }

      const allSheets = await db
        .select()
        .from(characterSheets);

      // Para cada ficha, obter dados completos
      const sheetsWithData = await Promise.all(
        allSheets.map(async (sheet) => {
          const sheetSkills = await db
            .select()
            .from(skills)
            .where(eq(skills.characterSheetId, sheet.id));

          const sheetWounds = await db
            .select()
            .from(wounds)
            .where(eq(wounds.characterSheetId, sheet.id));

          const sheetItems = await db
            .select()
            .from(bagItems)
            .where(eq(bagItems.characterSheetId, sheet.id));

          const sheetFortune = await db
            .select()
            .from(fortune)
            .where(eq(fortune.characterSheetId, sheet.id))
            .limit(1);

          return {
            sheet,
            skills: sheetSkills,
            wounds: sheetWounds,
            bagItems: sheetItems,
            fortune: sheetFortune[0] || null,
          };
        })
      );

      return sheetsWithData;
    }),
  }),
});

export type AppRouter = typeof appRouter;
