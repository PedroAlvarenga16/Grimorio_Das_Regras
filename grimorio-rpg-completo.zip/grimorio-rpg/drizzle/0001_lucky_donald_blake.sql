CREATE TABLE `bagItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`characterSheetId` int NOT NULL,
	`itemName` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bagItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `character_sheets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`characterName` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `character_sheets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fortune` (
	`id` int AUTO_INCREMENT NOT NULL,
	`characterSheetId` int NOT NULL,
	`currentPoints` int NOT NULL DEFAULT 0,
	`maxPoints` int NOT NULL DEFAULT 3,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fortune_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `skills` (
	`id` int AUTO_INCREMENT NOT NULL,
	`characterSheetId` int NOT NULL,
	`skillName` varchar(255) NOT NULL,
	`level` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `skills_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wounds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`characterSheetId` int NOT NULL,
	`quantity` int NOT NULL DEFAULT 1,
	`description` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wounds_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `bagItems` ADD CONSTRAINT `bagItems_characterSheetId_character_sheets_id_fk` FOREIGN KEY (`characterSheetId`) REFERENCES `character_sheets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `character_sheets` ADD CONSTRAINT `character_sheets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `fortune` ADD CONSTRAINT `fortune_characterSheetId_character_sheets_id_fk` FOREIGN KEY (`characterSheetId`) REFERENCES `character_sheets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `skills` ADD CONSTRAINT `skills_characterSheetId_character_sheets_id_fk` FOREIGN KEY (`characterSheetId`) REFERENCES `character_sheets`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `wounds` ADD CONSTRAINT `wounds_characterSheetId_character_sheets_id_fk` FOREIGN KEY (`characterSheetId`) REFERENCES `character_sheets`(`id`) ON DELETE cascade ON UPDATE no action;