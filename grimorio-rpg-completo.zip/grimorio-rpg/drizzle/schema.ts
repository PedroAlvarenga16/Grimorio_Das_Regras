import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Character sheet table - stores the main character data
 */
export const characterSheets = mysqlTable("character_sheets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  characterName: varchar("characterName", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CharacterSheet = typeof characterSheets.$inferSelect;
export type InsertCharacterSheet = typeof characterSheets.$inferInsert;

/**
 * Skills table - stores character skills with levels
 */
export const skills = mysqlTable("skills", {
  id: int("id").autoincrement().primaryKey(),
  characterSheetId: int("characterSheetId").notNull().references(() => characterSheets.id, { onDelete: "cascade" }),
  skillName: varchar("skillName", { length: 255 }).notNull(),
  level: int("level").default(1).notNull(), // 1-5
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = typeof skills.$inferInsert;

/**
 * Wounds table - stores character wounds/strikes
 */
export const wounds = mysqlTable("wounds", {
  id: int("id").autoincrement().primaryKey(),
  characterSheetId: int("characterSheetId").notNull().references(() => characterSheets.id, { onDelete: "cascade" }),
  quantity: int("quantity").default(1).notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Wound = typeof wounds.$inferSelect;
export type InsertWound = typeof wounds.$inferInsert;

/**
 * Bag items table - stores character inventory
 */
export const bagItems = mysqlTable("bagItems", {
  id: int("id").autoincrement().primaryKey(),
  characterSheetId: int("characterSheetId").notNull().references(() => characterSheets.id, { onDelete: "cascade" }),
  itemName: varchar("itemName", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BagItem = typeof bagItems.$inferSelect;
export type InsertBagItem = typeof bagItems.$inferInsert;

/**
 * Fortune/Luck table - stores character luck points
 */
export const fortune = mysqlTable("fortune", {
  id: int("id").autoincrement().primaryKey(),
  characterSheetId: int("characterSheetId").notNull().references(() => characterSheets.id, { onDelete: "cascade" }),
  currentPoints: int("currentPoints").default(0).notNull(),
  maxPoints: int("maxPoints").default(3).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Fortune = typeof fortune.$inferSelect;
export type InsertFortune = typeof fortune.$inferInsert;